# SIHCE.fhir.core#1.2.0: Guía de Implementación SIHCE - FHIR R4(en)

## Pages

* [Inicio](index.md)
* [Generalidades](Aspectos-Generales.md)
* [Artefactos](artifacts.md)
* [Casos de Uso](CasosDeUso.md)
* [Operaciones](Operaciones.md)
* [Seguridad](Seguridad.md)
* [Modelo Lógico](ModeloLogico.md)
* [Historial de Cambios](HistorialDeCambios.md)

## Resources

### Logicals

* [Modelo lógico BuscarPersona (FederadorBA)](StructureDefinition-BuscarPersona.md)
* [Modelo lógico FederarPersona (FederadorBA)](StructureDefinition-FederarPersona.md)
* [Modelo Lógico de Persona para SIHCE](StructureDefinition-MLPersona.md)
* [Modelo lógico ModificarIDLocalPersona (FederadorBA)](StructureDefinition-ModificarIDLocalPersona.md)
* [Modelo lógico ModificarSDMPersona (FederadorBA)](StructureDefinition-ModificarSDMPersona.md)

### Resource Profiles

* [Paciente SIHCE (PatientXBA)](StructureDefinition-PatientXBA.md)
* [Parametros Patch Identifier SIHCE](StructureDefinition-parametros-patch-identifier-sihce.md)
* [Parametros Update SDM SIHCE](StructureDefinition-parametros-update-sdm-sihce.md)

### ConceptMaps

* [BuscarPersona: modelo lógico a FHIR](ConceptMap-BuscarPersonaModeloAFHIR.md)
* [FederarPersona: modelo lógico a FHIR](ConceptMap-FederarPersonaModeloAFHIR.md)
* [ModificarIDLocalPersona: modelo lógico a FHIR](ConceptMap-ModificarIDLocalPersonaModeloAFHIR.md)
* [ModificarSDMPersona: modelo lógico a FHIR](ConceptMap-ModificarSDMPersonaModeloAFHIR.md)

### ImplementationGuides

* [Guía de Implementación SIHCE - FHIR R4](ImplementationGuide-SIHCE.fhir.core.md)

### NamingSystems

* [RenaperDNI](NamingSystem-renaper-dni.md)

### Examples

* [ParametrosPatchIdentifierEjemplo (Parameters)](Parameters-ParametrosPatchIdentifierEjemplo.md)
* [ParametrosUpdateSDMEjemplo (Parameters)](Parameters-ParametrosUpdateSDMEjemplo.md)
* [PersonaSIHCEMin (Patient)](Patient-PersonaSIHCEMin.md)

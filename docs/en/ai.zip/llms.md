# SIHCE.fhir.core#1.2.0: Guía de Implementación SIHCE - FHIR R5(en)

## Pages

* [Inicio](index.md)
* [Generalidades](Aspectos-Generales.md)
* [Artifacts Summary](artifacts.md)
* [Casos de Uso](CasosDeUso.md)
* [Operaciones](Operaciones.md)
* [Seguridad](Seguridad.md)
* [Modelo Lógico](ModeloLogico.md)
* [Historial de Cambios](HistorialDeCambios.md)

## Resources

### CodeSystems

* [Rutas de elementos FHIR usadas como destino en ConceptMap SIHCE](CodeSystem-sihce-fhir-core-element-paths.md)
* [Rutas de elementos en modelos lógicos de operación SIHCE](CodeSystem-sihce-logical-operation-element-paths.md)

### Logicals

* [Modelo lógico BuscarPersona (FederadorBA)](StructureDefinition-BuscarPersona.md)
* [Modelo lógico FederarPersona (FederadorBA)](StructureDefinition-FederarPersona.md)
* [Modelo Lógico de Persona para SIHCE](StructureDefinition-MLPersona.md)
* [Modelo lógico ModificarIDLocalPersona (FederadorBA)](StructureDefinition-ModificarIDLocalPersona.md)
* [Modelo lógico ModificarSDMPersona (FederadorBA)](StructureDefinition-ModificarSDMPersona.md)

### Resource Profiles

* [Paciente SIHCE (PatientXBA)](StructureDefinition-PatientXBA.md)
* [Parametros Patch Identifier SIHCE](StructureDefinition-parametros-patch-identifier-sihce.md)
* [Parametros Update SDM SIHCE](StructureDefinition-parametros-update-sdm-sihce.md)

### ConceptMaps

* [BuscarPersona: modelo lógico a FHIR](ConceptMap-BuscarPersonaModeloAFHIR.md)
* [FederarPersona: modelo lógico a FHIR](ConceptMap-FederarPersonaModeloAFHIR.md)
* [ModificarIDLocalPersona: modelo lógico a FHIR](ConceptMap-ModificarIDLocalPersonaModeloAFHIR.md)
* [ModificarSDMPersona: modelo lógico a FHIR](ConceptMap-ModificarSDMPersonaModeloAFHIR.md)

### ImplementationGuides

* [Guía de Implementación SIHCE - FHIR R5](ImplementationGuide-SIHCE.fhir.core.md)

### NamingSystems

* [NamingSystem URI Hospital Italiano (ejemplo FHIR)](NamingSystem-NamingSystemHospitalItalianoFHIR.md)
* [NamingSystem URI MSGC GCBA (ejemplo)](NamingSystem-NamingSystemMsgcGCBA.md)
* [RenaperDNI](NamingSystem-renaper-dni.md)

### Examples

* [ParametrosPatchIdentifierEjemplo (Parameters)](Parameters-ParametrosPatchIdentifierEjemplo.md)
* [ParametrosUpdateSDMEjemplo (Parameters)](Parameters-ParametrosUpdateSDMEjemplo.md)
* [PersonaSIHCEMin (Patient)](Patient-PersonaSIHCEMin.md)
* [PersonaSIHCEPatch (Patient)](Patient-PersonaSIHCEPatch.md)

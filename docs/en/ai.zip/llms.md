# SIHCE.fhir.core#2.2.2: Guía de Implementación SIHCE - FHIR R4(en)

## Pages

* [Inicio](index.md)
* [Operaciones — Documentos](Operaciones-Documentos.md)
* [Generalidades](Aspectos-Generales.md)
* [Casos de Uso — Documentos](CasosDeUso-Documentos.md)
* [Artifacts Summary](artifacts.md)
* [Casos de Uso](CasosDeUso.md)
* [Casos de Uso — Consentimiento](CasosDeUso-Consentimiento.md)
* [Operaciones](Operaciones.md)
* [Operaciones — Consentimiento](Operaciones-Consentimiento.md)
* [Seguridad](Seguridad.md)
* [Operaciones — Persona](Operaciones-Persona.md)
* [Epicrisis — secciones propuestas](Epicrisis-Secciones-Propuestas.md)
* [Modelo Lógico](ModeloLogico.md)
* [Epicrisis](Epicrisis.md)
* [Historial de Cambios](HistorialDeCambios.md)
* [Casos de Uso — Persona](CasosDeUso-Persona.md)

## Resources

### CodeSystems

* [Rutas de elementos FHIR usadas como destino en ConceptMap SIHCE](CodeSystem-sihce-fhir-core-element-paths.md)
* [Rutas de elementos en modelos lógicos de operación SIHCE](CodeSystem-sihce-logical-operation-element-paths.md)
* [Niveles de privacidad SIHCE](CodeSystem-sihce-privacy-level.md)

### ValueSets

* [Tipos de documento clínico SIHCE](ValueSet-sihce-clinical-document-type-vs.md)
* [Tipos MIME de contenido documental SIHCE](ValueSet-sihce-document-content-type-vs.md)
* [Diagnósticos epicrisis (ICD-10 y SNOMED CT AR) — propuesto](ValueSet-sihce-epicrisis-diagnosis-code-vs.md)
* [Secciones LOINC de epicrisis SIHCE](ValueSet-sihce-epicrisis-section-vs.md)
* [Motivo de internación epicrisis (ICD-10)](ValueSet-sihce-motivo-internacion-icd10-vs.md)
* [Niveles de privacidad SIHCE](ValueSet-sihce-privacy-level-vs.md)

### Logicals

* [Modelo lógico BuscarPersona (FederadorBA)](StructureDefinition-BuscarPersona.md)
* [Modelo lógico Consentimiento (SIHCE)](StructureDefinition-Consentimiento.md)
* [Modelo lógico DocumentoClinico (SIHCE)](StructureDefinition-DocumentoClinico.md)
* [Modelo lógico Epicrisis (SIHCE)](StructureDefinition-Epicrisis.md)
* [Modelo lógico FederarPersona (FederadorBA)](StructureDefinition-FederarPersona.md)
* [Modelo Lógico de Persona para SIHCE](StructureDefinition-MLPersona.md)
* [Modelo lógico ModificarIDLocalPersona (FederadorBA)](StructureDefinition-ModificarIDLocalPersona.md)
* [Modelo lógico ModificarSDMPersona (FederadorBA)](StructureDefinition-ModificarSDMPersona.md)

### Resource Profiles

* [Composición epicrisis SIHCE](StructureDefinition-CompositionEpicrisisSIHCE.md)
* [Condición clínica epicrisis SIHCE](StructureDefinition-ConditionEpicrisisSIHCE.md)
* [Consentimiento de paciente SIHCE](StructureDefinition-ConsentSIHCE.md)
* [Referencia a documento clínico SIHCE](StructureDefinition-DocumentReferenceSIHCE.md)
* [Medicación al alta epicrisis SIHCE](StructureDefinition-MedicationStatementEpicrisisSIHCE.md)
* [Paciente SIHCE (PatientXBA)](StructureDefinition-PatientXBA.md)
* [Parametros Patch Identifier SIHCE](StructureDefinition-parametros-patch-identifier-sihce.md)
* [Parametros Update SDM SIHCE](StructureDefinition-parametros-update-sdm-sihce.md)

### ConceptMaps

* [BuscarPersona: modelo lógico a FHIR](ConceptMap-BuscarPersonaModeloAFHIR.md)
* [Consentimiento: modelo lógico a FHIR](ConceptMap-ConsentimientoModeloAFHIR.md)
* [DocumentoClinico: modelo lógico a FHIR](ConceptMap-DocumentoClinicoModeloAFHIR.md)
* [Epicrisis: modelo lógico a FHIR](ConceptMap-EpicrisisModeloAFHIR.md)
* [FederarPersona: modelo lógico a FHIR](ConceptMap-FederarPersonaModeloAFHIR.md)
* [ModificarIDLocalPersona: modelo lógico a FHIR](ConceptMap-ModificarIDLocalPersonaModeloAFHIR.md)
* [ModificarSDMPersona: modelo lógico a FHIR](ConceptMap-ModificarSDMPersonaModeloAFHIR.md)

### ImplementationGuides

* [Guía de Implementación SIHCE - FHIR R4](ImplementationGuide-SIHCE.fhir.core.md)

### NamingSystems

* [NamingSystemHospitalItalianoFHIR](NamingSystem-NamingSystemHospitalItalianoFHIR.md)
* [NamingSystemMsgcGCBA](NamingSystem-NamingSystemMsgcGCBA.md)
* [NamingSystemOrganizationHospitalMsgc](NamingSystem-NamingSystemOrganizationHospitalMsgc.md)
* [RenaperDNI](NamingSystem-renaper-dni.md)
* [SihcePersonaGlobal](NamingSystem-sihce-persona-global.md)

### Examples

* [Epicrisis de hospitalización (Composition)](Composition-CompositionEpicrisisNivel2.md)
* [Epicrisis de hospitalización (nivel 3) (Composition)](Composition-CompositionEpicrisisNivel3.md)
* [ConditionMotivoInternacionEjemplo (Condition)](Condition-ConditionMotivoInternacionEjemplo.md)
* [ConsentOptInGeneralSIHCE (Consent)](Consent-ConsentOptInGeneralSIHCE.md)
* [ConsentOptInHospitalConfidentialSIHCE (Consent)](Consent-ConsentOptInHospitalConfidentialSIHCE.md)
* [ConsentOptInHospitalNormalSIHCE (Consent)](Consent-ConsentOptInHospitalNormalSIHCE.md)
* [ConsentOptInHospitalSIHCE (Consent)](Consent-ConsentOptInHospitalSIHCE.md)
* [ConsentOptOutGeneralSIHCE (Consent)](Consent-ConsentOptOutGeneralSIHCE.md)
* [DocumentReferenceEpicrisisNivel1 (DocumentReference)](DocumentReference-DocumentReferenceEpicrisisNivel1.md)
* [DocumentReferenceEpicrisisNivel2 (DocumentReference)](DocumentReference-DocumentReferenceEpicrisisNivel2.md)
* [DocumentReferenceEpicrisisNivel3 (DocumentReference)](DocumentReference-DocumentReferenceEpicrisisNivel3.md)
* [ParametrosPatchIdentifierEjemplo (Parameters)](Parameters-ParametrosPatchIdentifierEjemplo.md)
* [ParametrosUpdateSDMEjemplo (Parameters)](Parameters-ParametrosUpdateSDMEjemplo.md)
* [PersonaSIHCEMin (Patient)](Patient-PersonaSIHCEMin.md)
* [PersonaSIHCEPatch (Patient)](Patient-PersonaSIHCEPatch.md)

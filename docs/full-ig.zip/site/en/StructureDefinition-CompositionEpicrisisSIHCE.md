# Composición epicrisis SIHCE - Guía de Implementación SIHCE - FHIR R4 v2.2.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Composición epicrisis SIHCE**

## Resource Profile: Composición epicrisis SIHCE 

| | | |
| :--- | :--- | :--- |
| *Official URL*:http://sihce.gob.ar/StructureDefinition/CompositionEpicrisisSIHCE | *Version*:2.2.2 | |
| * Standards status: *[Trial-use](http://hl7.org/fhir/R4/versions.html#std-process) | [Maturity Level](http://hl7.org/fhir/versions.html#maturity): 3 | *Computable Name*:CompositionEpicrisisSIHCE |

 
Documento estructurado de epicrisis (LOINC 18842-5). Nivel 2: secciones tipadas con text. Nivel 3: solo Motivo de internación (46241-6) con entry Condition + ICD-10. Resto de codificaciones en propuestas de votación. 

**Usages:**

* Examples for this Profile: [Composition/CompositionEpicrisisNivel2](Composition-CompositionEpicrisisNivel2.md) and [Composition/CompositionEpicrisisNivel3](Composition-CompositionEpicrisisNivel3.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/SIHCE.fhir.core|current/StructureDefinition/StructureDefinition-CompositionEpicrisisSIHCE.json)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots, and their representations](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](../StructureDefinition-CompositionEpicrisisSIHCE.csv), [Excel](../StructureDefinition-CompositionEpicrisisSIHCE.xlsx), [Schematron](../StructureDefinition-CompositionEpicrisisSIHCE.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "CompositionEpicrisisSIHCE",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-fmm",
    "valueInteger" : 3
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-standards-status",
    "valueCode" : "trial-use"
  }],
  "url" : "http://sihce.gob.ar/StructureDefinition/CompositionEpicrisisSIHCE",
  "version" : "2.2.2",
  "name" : "CompositionEpicrisisSIHCE",
  "title" : "Composición epicrisis SIHCE",
  "status" : "active",
  "date" : "2026-06-09T00:00:00-03:00",
  "publisher" : "SIHCE Development Team",
  "contact" : [{
    "name" : "SIHCE Development Team",
    "telecom" : [{
      "system" : "url",
      "value" : "https://github.com/diegokaminker/sihce-ig"
    }]
  }],
  "description" : "Documento estructurado de epicrisis (LOINC 18842-5). Nivel 2: secciones tipadas con text. Nivel 3: solo Motivo de internación (46241-6) con entry Condition + ICD-10. Resto de codificaciones en propuestas de votación.",
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "workflow",
    "uri" : "http://hl7.org/fhir/workflow",
    "name" : "Workflow Pattern"
  },
  {
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "cda",
    "uri" : "http://hl7.org/v3/cda",
    "name" : "CDA (R2)"
  },
  {
    "identity" : "fhirdocumentreference",
    "uri" : "http://hl7.org/fhir/documentreference",
    "name" : "FHIR DocumentReference"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "Composition",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Composition",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "Composition",
      "path" : "Composition"
    },
    {
      "id" : "Composition.status",
      "path" : "Composition.status",
      "patternCode" : "final",
      "mustSupport" : true
    },
    {
      "id" : "Composition.type",
      "path" : "Composition.type",
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "http://loinc.org",
          "code" : "18842-5",
          "display" : "Discharge Summary"
        }]
      },
      "mustSupport" : true
    },
    {
      "id" : "Composition.subject",
      "path" : "Composition.subject",
      "min" : 1,
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Patient"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Composition.subject.reference",
      "path" : "Composition.subject.reference",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "Composition.date",
      "path" : "Composition.date",
      "mustSupport" : true
    },
    {
      "id" : "Composition.author",
      "path" : "Composition.author",
      "mustSupport" : true
    },
    {
      "id" : "Composition.title",
      "path" : "Composition.title",
      "short" : "Título legible de la epicrisis",
      "mustSupport" : true
    },
    {
      "id" : "Composition.custodian",
      "path" : "Composition.custodian",
      "mustSupport" : true
    },
    {
      "id" : "Composition.section",
      "path" : "Composition.section",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "code.coding.code"
        }],
        "rules" : "open"
      },
      "mustSupport" : true
    },
    {
      "id" : "Composition.section:alergias",
      "path" : "Composition.section",
      "sliceName" : "alergias",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Composition.section:alergias.code.coding",
      "path" : "Composition.section.code.coding",
      "min" : 1,
      "max" : "1"
    },
    {
      "id" : "Composition.section:alergias.code.coding.system",
      "path" : "Composition.section.code.coding.system",
      "patternUri" : "http://loinc.org"
    },
    {
      "id" : "Composition.section:alergias.code.coding.code",
      "path" : "Composition.section.code.coding.code",
      "min" : 1,
      "patternCode" : "48765-2"
    },
    {
      "id" : "Composition.section:alergias.code.coding.display",
      "path" : "Composition.section.code.coding.display",
      "patternString" : "Allergies and adverse reactions Document"
    },
    {
      "id" : "Composition.section:alergias.text",
      "path" : "Composition.section.text",
      "mustSupport" : true
    },
    {
      "id" : "Composition.section:diagnosticoAlta",
      "path" : "Composition.section",
      "sliceName" : "diagnosticoAlta",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Composition.section:diagnosticoAlta.code.coding",
      "path" : "Composition.section.code.coding",
      "min" : 1,
      "max" : "1"
    },
    {
      "id" : "Composition.section:diagnosticoAlta.code.coding.system",
      "path" : "Composition.section.code.coding.system",
      "patternUri" : "http://loinc.org"
    },
    {
      "id" : "Composition.section:diagnosticoAlta.code.coding.code",
      "path" : "Composition.section.code.coding.code",
      "min" : 1,
      "patternCode" : "78375-3"
    },
    {
      "id" : "Composition.section:diagnosticoAlta.code.coding.display",
      "path" : "Composition.section.code.coding.display",
      "patternString" : "Discharge diagnosis Narrative"
    },
    {
      "id" : "Composition.section:diagnosticoAlta.text",
      "path" : "Composition.section.text",
      "mustSupport" : true
    },
    {
      "id" : "Composition.section:medicamentosAlta",
      "path" : "Composition.section",
      "sliceName" : "medicamentosAlta",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Composition.section:medicamentosAlta.code.coding",
      "path" : "Composition.section.code.coding",
      "min" : 1,
      "max" : "1"
    },
    {
      "id" : "Composition.section:medicamentosAlta.code.coding.system",
      "path" : "Composition.section.code.coding.system",
      "patternUri" : "http://loinc.org"
    },
    {
      "id" : "Composition.section:medicamentosAlta.code.coding.code",
      "path" : "Composition.section.code.coding.code",
      "min" : 1,
      "patternCode" : "75311-1"
    },
    {
      "id" : "Composition.section:medicamentosAlta.code.coding.display",
      "path" : "Composition.section.code.coding.display",
      "patternString" : "Discharge medications note"
    },
    {
      "id" : "Composition.section:medicamentosAlta.text",
      "path" : "Composition.section.text",
      "mustSupport" : true
    },
    {
      "id" : "Composition.section:evolucionHospitalaria",
      "path" : "Composition.section",
      "sliceName" : "evolucionHospitalaria",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Composition.section:evolucionHospitalaria.code.coding",
      "path" : "Composition.section.code.coding",
      "min" : 1,
      "max" : "1"
    },
    {
      "id" : "Composition.section:evolucionHospitalaria.code.coding.system",
      "path" : "Composition.section.code.coding.system",
      "patternUri" : "http://loinc.org"
    },
    {
      "id" : "Composition.section:evolucionHospitalaria.code.coding.code",
      "path" : "Composition.section.code.coding.code",
      "min" : 1,
      "patternCode" : "8648-8"
    },
    {
      "id" : "Composition.section:evolucionHospitalaria.code.coding.display",
      "path" : "Composition.section.code.coding.display",
      "patternString" : "Hospital course note"
    },
    {
      "id" : "Composition.section:evolucionHospitalaria.text",
      "path" : "Composition.section.text",
      "mustSupport" : true
    },
    {
      "id" : "Composition.section:planTratamiento",
      "path" : "Composition.section",
      "sliceName" : "planTratamiento",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Composition.section:planTratamiento.code.coding",
      "path" : "Composition.section.code.coding",
      "min" : 1,
      "max" : "1"
    },
    {
      "id" : "Composition.section:planTratamiento.code.coding.system",
      "path" : "Composition.section.code.coding.system",
      "patternUri" : "http://loinc.org"
    },
    {
      "id" : "Composition.section:planTratamiento.code.coding.code",
      "path" : "Composition.section.code.coding.code",
      "min" : 1,
      "patternCode" : "18776-5"
    },
    {
      "id" : "Composition.section:planTratamiento.code.coding.display",
      "path" : "Composition.section.code.coding.display",
      "patternString" : "Plan of Care Note"
    },
    {
      "id" : "Composition.section:planTratamiento.text",
      "path" : "Composition.section.text",
      "mustSupport" : true
    },
    {
      "id" : "Composition.section:diagnosticoAdmision",
      "path" : "Composition.section",
      "sliceName" : "diagnosticoAdmision",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Composition.section:diagnosticoAdmision.code.coding",
      "path" : "Composition.section.code.coding",
      "min" : 1,
      "max" : "1"
    },
    {
      "id" : "Composition.section:diagnosticoAdmision.code.coding.system",
      "path" : "Composition.section.code.coding.system",
      "patternUri" : "http://loinc.org"
    },
    {
      "id" : "Composition.section:diagnosticoAdmision.code.coding.code",
      "path" : "Composition.section.code.coding.code",
      "min" : 1,
      "patternCode" : "42347-5"
    },
    {
      "id" : "Composition.section:diagnosticoAdmision.code.coding.display",
      "path" : "Composition.section.code.coding.display",
      "patternString" : "Admission diagnosis (narrative)"
    },
    {
      "id" : "Composition.section:diagnosticoAdmision.text",
      "path" : "Composition.section.text",
      "mustSupport" : true
    },
    {
      "id" : "Composition.section:medicamentosIngreso",
      "path" : "Composition.section",
      "sliceName" : "medicamentosIngreso",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Composition.section:medicamentosIngreso.code.coding",
      "path" : "Composition.section.code.coding",
      "min" : 1,
      "max" : "1"
    },
    {
      "id" : "Composition.section:medicamentosIngreso.code.coding.system",
      "path" : "Composition.section.code.coding.system",
      "patternUri" : "http://loinc.org"
    },
    {
      "id" : "Composition.section:medicamentosIngreso.code.coding.code",
      "path" : "Composition.section.code.coding.code",
      "min" : 1,
      "patternCode" : "42346-7"
    },
    {
      "id" : "Composition.section:medicamentosIngreso.code.coding.display",
      "path" : "Composition.section.code.coding.display",
      "patternString" : "Medications on admission (narrative)"
    },
    {
      "id" : "Composition.section:medicamentosIngreso.text",
      "path" : "Composition.section.text",
      "mustSupport" : true
    },
    {
      "id" : "Composition.section:motivoInternacion",
      "path" : "Composition.section",
      "sliceName" : "motivoInternacion",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Composition.section:motivoInternacion.code.coding",
      "path" : "Composition.section.code.coding",
      "min" : 1,
      "max" : "1"
    },
    {
      "id" : "Composition.section:motivoInternacion.code.coding.system",
      "path" : "Composition.section.code.coding.system",
      "patternUri" : "http://loinc.org"
    },
    {
      "id" : "Composition.section:motivoInternacion.code.coding.code",
      "path" : "Composition.section.code.coding.code",
      "min" : 1,
      "patternCode" : "46241-6"
    },
    {
      "id" : "Composition.section:motivoInternacion.code.coding.display",
      "path" : "Composition.section.code.coding.display",
      "patternString" : "Hospital admission diagnosis Narrative - Reported"
    },
    {
      "id" : "Composition.section:motivoInternacion.text",
      "path" : "Composition.section.text",
      "mustSupport" : true
    },
    {
      "id" : "Composition.section:motivoInternacion.entry",
      "path" : "Composition.section.entry",
      "short" : "Nivel 3: Condition con código ICD-10",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://sihce.gob.ar/StructureDefinition/ConditionEpicrisisSIHCE"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "Composition.section:instruccionesAlta",
      "path" : "Composition.section",
      "sliceName" : "instruccionesAlta",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Composition.section:instruccionesAlta.code.coding",
      "path" : "Composition.section.code.coding",
      "min" : 1,
      "max" : "1"
    },
    {
      "id" : "Composition.section:instruccionesAlta.code.coding.system",
      "path" : "Composition.section.code.coding.system",
      "patternUri" : "http://loinc.org"
    },
    {
      "id" : "Composition.section:instruccionesAlta.code.coding.code",
      "path" : "Composition.section.code.coding.code",
      "min" : 1,
      "patternCode" : "8653-8"
    },
    {
      "id" : "Composition.section:instruccionesAlta.code.coding.display",
      "path" : "Composition.section.code.coding.display",
      "patternString" : "Hospital Discharge Instructions"
    },
    {
      "id" : "Composition.section:instruccionesAlta.text",
      "path" : "Composition.section.text",
      "mustSupport" : true
    },
    {
      "id" : "Composition.section:resumenEstudios",
      "path" : "Composition.section",
      "sliceName" : "resumenEstudios",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Composition.section:resumenEstudios.code.coding",
      "path" : "Composition.section.code.coding",
      "min" : 1,
      "max" : "1"
    },
    {
      "id" : "Composition.section:resumenEstudios.code.coding.system",
      "path" : "Composition.section.code.coding.system",
      "patternUri" : "http://loinc.org"
    },
    {
      "id" : "Composition.section:resumenEstudios.code.coding.code",
      "path" : "Composition.section.code.coding.code",
      "min" : 1,
      "patternCode" : "11493-4"
    },
    {
      "id" : "Composition.section:resumenEstudios.code.coding.display",
      "path" : "Composition.section.code.coding.display",
      "patternString" : "Hospital discharge studies summary Narrative"
    },
    {
      "id" : "Composition.section:resumenEstudios.text",
      "path" : "Composition.section.text",
      "mustSupport" : true
    },
    {
      "id" : "Composition.section:hallazgosFisicos",
      "path" : "Composition.section",
      "sliceName" : "hallazgosFisicos",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Composition.section:hallazgosFisicos.code.coding",
      "path" : "Composition.section.code.coding",
      "min" : 1,
      "max" : "1"
    },
    {
      "id" : "Composition.section:hallazgosFisicos.code.coding.system",
      "path" : "Composition.section.code.coding.system",
      "patternUri" : "http://loinc.org"
    },
    {
      "id" : "Composition.section:hallazgosFisicos.code.coding.code",
      "path" : "Composition.section.code.coding.code",
      "min" : 1,
      "patternCode" : "10184-0"
    },
    {
      "id" : "Composition.section:hallazgosFisicos.code.coding.display",
      "path" : "Composition.section.code.coding.display",
      "patternString" : "Hospital discharge physical findings Narrative"
    },
    {
      "id" : "Composition.section:hallazgosFisicos.text",
      "path" : "Composition.section.text",
      "mustSupport" : true
    },
    {
      "id" : "Composition.section:historialProcedimientos",
      "path" : "Composition.section",
      "sliceName" : "historialProcedimientos",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Composition.section:historialProcedimientos.code.coding",
      "path" : "Composition.section.code.coding",
      "min" : 1,
      "max" : "1"
    },
    {
      "id" : "Composition.section:historialProcedimientos.code.coding.system",
      "path" : "Composition.section.code.coding.system",
      "patternUri" : "http://loinc.org"
    },
    {
      "id" : "Composition.section:historialProcedimientos.code.coding.code",
      "path" : "Composition.section.code.coding.code",
      "min" : 1,
      "patternCode" : "47519-4"
    },
    {
      "id" : "Composition.section:historialProcedimientos.code.coding.display",
      "path" : "Composition.section.code.coding.display",
      "patternString" : "History of Procedures Document"
    },
    {
      "id" : "Composition.section:historialProcedimientos.text",
      "path" : "Composition.section.text",
      "mustSupport" : true
    },
    {
      "id" : "Composition.section:listaProblemas",
      "path" : "Composition.section",
      "sliceName" : "listaProblemas",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "Composition.section:listaProblemas.code.coding",
      "path" : "Composition.section.code.coding",
      "min" : 1,
      "max" : "1"
    },
    {
      "id" : "Composition.section:listaProblemas.code.coding.system",
      "path" : "Composition.section.code.coding.system",
      "patternUri" : "http://loinc.org"
    },
    {
      "id" : "Composition.section:listaProblemas.code.coding.code",
      "path" : "Composition.section.code.coding.code",
      "min" : 1,
      "patternCode" : "11450-4"
    },
    {
      "id" : "Composition.section:listaProblemas.code.coding.display",
      "path" : "Composition.section.code.coding.display",
      "patternString" : "Problem list - Reported"
    },
    {
      "id" : "Composition.section:listaProblemas.text",
      "path" : "Composition.section.text",
      "mustSupport" : true
    }]
  }
}

```

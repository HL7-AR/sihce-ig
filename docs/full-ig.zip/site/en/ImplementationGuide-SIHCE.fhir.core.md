# Resource Guía de Implementación SIHCE - FHIR R5



## Resource Content

```json
{
  "resourceType" : "ImplementationGuide",
  "id" : "SIHCE.fhir.core",
  "language" : "en",
  "url" : "http://sihce.gob.ar/ImplementationGuide/SIHCE.fhir.core",
  "version" : "1.4.0",
  "name" : "GuiaDeImplementacionSIHCE",
  "title" : "Guía de Implementación SIHCE - FHIR R5",
  "status" : "draft",
  "date" : "2026-08-26T18:52:04-03:00",
  "publisher" : "SIHCE Development Team",
  "contact" : [{
    "name" : "SIHCE Development Team",
    "telecom" : [{
      "system" : "url",
      "value" : "https://github.com/diegokaminker/sihce-ig"
    }]
  }],
  "packageId" : "SIHCE.fhir.core",
  "license" : "CC0-1.0",
  "fhirVersion" : ["5.0.0"],
  "dependsOn" : [{
    "id" : "hl7tx",
    "extension" : [{
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-dependency-comment",
      "valueMarkdown" : "Automatically added as a dependency - all IGs depend on HL7 Terminology"
    }],
    "uri" : "http://terminology.hl7.org/ImplementationGuide/hl7.terminology",
    "packageId" : "hl7.terminology.r5",
    "version" : "7.3.0"
  },
  {
    "id" : "hl7ext",
    "extension" : [{
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-dependency-comment",
      "valueMarkdown" : "Automatically added as a dependency - all IGs depend on the HL7 Extension Pack"
    }],
    "uri" : "http://hl7.org/fhir/extensions/ImplementationGuide/hl7.fhir.uv.extensions",
    "packageId" : "hl7.fhir.uv.extensions.r5",
    "version" : "5.3.0"
  }],
  "definition" : {
    "extension" : [{
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-internal-dependency",
      "valueCode" : "hl7.fhir.uv.tools.r5#1.1.2"
    }],
    "resource" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/sihce-lab-observation-code-vs"
      },
      "name" : "Analitos de laboratorio SIHCE (LOINC)",
      "description" : "Códigos LOINC para ObservationLaboratorioSIHCE en informes nivel 2.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      }],
      "reference" : {
        "reference" : "ConceptMap/BuscarPersonaModeloAFHIR"
      },
      "name" : "BuscarPersona: modelo lógico a FHIR",
      "description" : "Mapeo explícito de campos del modelo lógico BuscarPersona a elementos Patient y Organization (FHIR R5).",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/CompositionEpicrisisSIHCE"
      },
      "name" : "Composición epicrisis SIHCE",
      "description" : "Documento estructurado de epicrisis (LOINC 18842-5). Nivel 2: secciones obligatorias con text. Nivel 3: secciones codificadas con entry (Condition, MedicationStatement).",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ConditionEpicrisisSIHCE"
      },
      "name" : "Condición clínica epicrisis SIHCE",
      "description" : "Diagnóstico codificado en secciones de epicrisis nivel 3 (ICD-10 o SNOMED CT edición Argentina).",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ConsentSIHCE"
      },
      "name" : "Consentimiento de paciente SIHCE",
      "description" : "Preferencias de privacidad del paciente en la red SIHCE (FHIR R5). Etapa 1: decision permit/deny (opt-in/out general). Etapa 2: provision con actor Organization (hospital). Etapa 3: securityLabel normal o confidential (obligatorio y explícito).",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Consent"
      }],
      "reference" : {
        "reference" : "Consent/ConsentOptInHospitalConfidentialSIHCE"
      },
      "name" : "Consentimiento hospital + nivel confidential (etapa 3)",
      "description" : "Hospital Central autorizado también para documentos confidential.",
      "isExample" : true,
      "profile" : ["http://sihce.gob.ar/StructureDefinition/ConsentSIHCE"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Consent"
      }],
      "reference" : {
        "reference" : "Consent/ConsentOptInHospitalNormalSIHCE"
      },
      "name" : "Consentimiento hospital + nivel normal (etapa 3)",
      "description" : "Hospital Central autorizado con nivel normal explícito.",
      "isExample" : true,
      "profile" : ["http://sihce.gob.ar/StructureDefinition/ConsentSIHCE"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Consent"
      }],
      "reference" : {
        "reference" : "Consent/ConsentOptInGeneralSIHCE"
      },
      "name" : "Consentimiento opt-in general (etapa 1)",
      "description" : "Paciente autoriza participación general en la red SIHCE.",
      "isExample" : true,
      "profile" : ["http://sihce.gob.ar/StructureDefinition/ConsentSIHCE"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Consent"
      }],
      "reference" : {
        "reference" : "Consent/ConsentOptInHospitalSIHCE"
      },
      "name" : "Consentimiento opt-in por hospital (etapa 2)",
      "description" : "Opt-in general con autorización explícita al Hospital Central (dominio MSGC).",
      "isExample" : true,
      "profile" : ["http://sihce.gob.ar/StructureDefinition/ConsentSIHCE"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Consent"
      }],
      "reference" : {
        "reference" : "Consent/ConsentOptOutGeneralSIHCE"
      },
      "name" : "Consentimiento opt-out general",
      "description" : "Paciente revoca toda participación; anula autorizaciones previas.",
      "isExample" : true,
      "profile" : ["http://sihce.gob.ar/StructureDefinition/ConsentSIHCE"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      }],
      "reference" : {
        "reference" : "ConceptMap/ConsentimientoModeloAFHIR"
      },
      "name" : "Consentimiento: modelo lógico a FHIR",
      "description" : "Mapeo del registro de consentimiento del paciente a Consent SIHCE.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/sihce-epicrisis-diagnosis-code-vs"
      },
      "name" : "Diagnósticos epicrisis (ICD-10 y SNOMED CT AR)",
      "description" : "Códigos de Condition en secciones codificadas de epicrisis (nivel 3). Binding extensible: se admiten códigos ICD-10 y SNOMED CT edición Argentina; este ValueSet lista códigos representativos para publicación.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      }],
      "reference" : {
        "reference" : "ConceptMap/DocumentoClinicoModeloAFHIR"
      },
      "name" : "DocumentoClinico: modelo lógico a FHIR",
      "description" : "Mapeo del registro de documento clínico a DocumentReference SIHCE.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Parameters"
      }],
      "reference" : {
        "reference" : "Parameters/ParametrosPatchIdentifierEjemplo"
      },
      "name" : "Ejemplo Parameters Patch Identifier",
      "description" : "Ejemplo de Parámetros para actualizar identificador local.",
      "isExample" : true,
      "profile" : ["http://sihce.gob.ar/StructureDefinition/parametros-patch-identifier-sihce"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Parameters"
      }],
      "reference" : {
        "reference" : "Parameters/ParametrosUpdateSDMEjemplo"
      },
      "name" : "Ejemplo Parameters Update SDM",
      "description" : "Ejemplo de Parametros para actualizacion de SDM.",
      "isExample" : true,
      "profile" : ["http://sihce.gob.ar/StructureDefinition/parametros-update-sdm-sihce"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "DocumentReference"
      }],
      "reference" : {
        "reference" : "DocumentReference/DocumentReferenceEpicrisisNivel1"
      },
      "name" : "Epicrisis nivel 1 — PDF en dominio",
      "description" : "DocumentReference con enlace a PDF hospedado en el dominio emisor. Paciente: PersonaSIHCEMin.",
      "isExample" : true,
      "profile" : ["http://sihce.gob.ar/StructureDefinition/DocumentReferenceSIHCE"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "DocumentReference"
      }],
      "reference" : {
        "reference" : "DocumentReference/DocumentReferenceEpicrisisNivel2"
      },
      "name" : "Epicrisis nivel 2 — enlace a Composition",
      "description" : "DocumentReference con URL a Composition narrativa en el dominio.",
      "isExample" : true,
      "profile" : ["http://sihce.gob.ar/StructureDefinition/DocumentReferenceSIHCE"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Composition"
      }],
      "reference" : {
        "reference" : "Composition/CompositionEpicrisisNivel2"
      },
      "name" : "Epicrisis nivel 2 — secciones narrativas",
      "description" : "Composition con las cinco secciones obligatorias en texto (nivel 2).",
      "isExample" : true,
      "profile" : ["http://sihce.gob.ar/StructureDefinition/CompositionEpicrisisSIHCE"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      }],
      "reference" : {
        "reference" : "ConceptMap/EpicrisisModeloAFHIR"
      },
      "name" : "Epicrisis: modelo lógico a FHIR",
      "description" : "Mapeo de secciones de epicrisis a Composition.section (niveles 2 y 3).",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      }],
      "reference" : {
        "reference" : "ConceptMap/FederarPersonaModeloAFHIR"
      },
      "name" : "FederarPersona: modelo lógico a FHIR",
      "description" : "Mapeo explícito del modelo FederarPersona a Patient, Organization y mensajes de resultado.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DiagnosticReportLaboratorioSIHCE"
      },
      "name" : "Informe de laboratorio SIHCE",
      "description" : "DiagnosticReport referenciado desde DocumentReference (LOINC 11502-2). Nivel 1: presentedForm PDF. Nivel 2: presentedForm + result con Observation codificadas.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "DiagnosticReport"
      }],
      "reference" : {
        "reference" : "DiagnosticReport/DiagnosticReportInformeLabNivel1"
      },
      "name" : "Informe laboratorio nivel 1 — DiagnosticReport con PDF",
      "description" : "Solo presentedForm (PDF); sin entradas en result (nivel 1).",
      "isExample" : true,
      "profile" : ["http://sihce.gob.ar/StructureDefinition/DiagnosticReportLaboratorioSIHCE"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "DocumentReference"
      }],
      "reference" : {
        "reference" : "DocumentReference/DocumentReferenceInformeLabNivel1"
      },
      "name" : "Informe laboratorio nivel 1 — enlace a DiagnosticReport (solo PDF)",
      "description" : "Índice SIHCE; la URL apunta a un DiagnosticReport con presentedForm PDF sin observaciones codificadas. Paciente: [PersonaSIHCEMin](Patient-PersonaSIHCEMin.html).",
      "isExample" : true,
      "profile" : ["http://sihce.gob.ar/StructureDefinition/DocumentReferenceSIHCE"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "DiagnosticReport"
      }],
      "reference" : {
        "reference" : "DiagnosticReport/DiagnosticReportInformeLabNivel2"
      },
      "name" : "Informe laboratorio nivel 2 — PDF + glucemia y urea",
      "description" : "Basado en docs/examples/diagnosticreport.json (simplificado): presentedForm PDF y Observation LOINC en contained/result.",
      "isExample" : true,
      "profile" : ["http://sihce.gob.ar/StructureDefinition/DiagnosticReportLaboratorioSIHCE"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "DocumentReference"
      }],
      "reference" : {
        "reference" : "DocumentReference/DocumentReferenceInformeLabNivel2"
      },
      "name" : "Informe laboratorio nivel 2 — PDF y observaciones",
      "description" : "Índice SIHCE; URL a DiagnosticReport con presentedForm y Observation contenidas en result.",
      "isExample" : true,
      "profile" : ["http://sihce.gob.ar/StructureDefinition/DocumentReferenceSIHCE"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      }],
      "reference" : {
        "reference" : "ConceptMap/InformeLaboratorioModeloAFHIR"
      },
      "name" : "InformeLaboratorio: modelo lógico a FHIR",
      "description" : "Mapeo del informe de laboratorio a DocumentReference e DiagnosticReport.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Organization"
      }],
      "reference" : {
        "reference" : "Organization/lab-central-ejemplo"
      },
      "name" : "Laboratorio Central Ejemplo",
      "isExample" : true
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/MedicationStatementEpicrisisSIHCE"
      },
      "name" : "Medicación al alta epicrisis SIHCE",
      "description" : "Medicamento declarado en la sección de medicamentos al alta (nivel 3).",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      }],
      "reference" : {
        "reference" : "StructureDefinition/BuscarPersona"
      },
      "name" : "Modelo lógico BuscarPersona (FederadorBA)",
      "description" : "Solicitud de búsqueda de persona por datos mínimos y respuesta mínima.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      }],
      "reference" : {
        "reference" : "StructureDefinition/Consentimiento"
      },
      "name" : "Modelo lógico Consentimiento (SIHCE)",
      "description" : "Registro de preferencias de privacidad del paciente en SIHCE. Tres etapas de madurez: opt-in/out general, opt-in por hospital, hospital + nivel de privacidad.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      }],
      "reference" : {
        "reference" : "StructureDefinition/MLPersona"
      },
      "name" : "Modelo Lógico de Persona para SIHCE",
      "description" : "Modelo Lógico de Persona para SIHCE con foco en empadronamiento e identificación",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DocumentoClinico"
      },
      "name" : "Modelo lógico DocumentoClinico (SIHCE)",
      "description" : "Registro e indexación de un documento clínico emitido por un dominio en SIHCE.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      }],
      "reference" : {
        "reference" : "StructureDefinition/Epicrisis"
      },
      "name" : "Modelo lógico Epicrisis (SIHCE)",
      "description" : "Epicrisis (discharge summary) como caso particular de DocumentoClinico con niveles de madurez 1–3.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      }],
      "reference" : {
        "reference" : "StructureDefinition/FederarPersona"
      },
      "name" : "Modelo lógico FederarPersona (FederadorBA)",
      "description" : "Federación de una persona con identificador local y validación de datos.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      }],
      "reference" : {
        "reference" : "StructureDefinition/InformeLaboratorio"
      },
      "name" : "Modelo lógico Informe de Laboratorio (SIHCE)",
      "description" : "Informe de laboratorio indexado vía DocumentReference; contenido DiagnosticReport en URL del dominio.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ModificarIDLocalPersona"
      },
      "name" : "Modelo lógico ModificarIDLocalPersona (FederadorBA)",
      "description" : "Modificación del identificador local de una persona federada.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ModificarSDMPersona"
      },
      "name" : "Modelo lógico ModificarSDMPersona (FederadorBA)",
      "description" : "Actualización del SDM de una persona federada; documento inmutable.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      }],
      "reference" : {
        "reference" : "ConceptMap/ModificarIDLocalPersonaModeloAFHIR"
      },
      "name" : "ModificarIDLocalPersona: modelo lógico a FHIR",
      "description" : "Mapeo del modelo ModificarIDLocalPersona a Patient (SDM, identificadores) y OperationOutcome (mensaje).",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      }],
      "reference" : {
        "reference" : "ConceptMap/ModificarSDMPersonaModeloAFHIR"
      },
      "name" : "ModificarSDMPersona: modelo lógico a FHIR",
      "description" : "Mapeo del modelo ModificarSDMPersona (SDM actual y nuevo, dominio, respuesta) a Patient y OperationOutcome.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "NamingSystem"
      }],
      "reference" : {
        "reference" : "NamingSystem/sihce-persona-global"
      },
      "name" : "NamingSystem idPersonaGlobal SIHCE",
      "description" : "Identificador maestro de persona asignado por SIHCE tras la federación (idPersonaGlobal).",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "NamingSystem"
      }],
      "reference" : {
        "reference" : "NamingSystem/NamingSystemOrganizationHospitalMsgc"
      },
      "name" : "NamingSystem Organization hospital (dominio MSGC, ejemplo)",
      "description" : "Patrón de identificación de hospitales dentro de un dominio SIHCE: system = {uri-dominio}/Organization, value = id local del hospital.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "NamingSystem"
      }],
      "reference" : {
        "reference" : "NamingSystem/NamingSystemHospitalItalianoFHIR"
      },
      "name" : "NamingSystem URI Hospital Italiano (ejemplo FHIR)",
      "description" : "Identificador de dominio de ejemplo usado en instancias de este IG.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "NamingSystem"
      }],
      "reference" : {
        "reference" : "NamingSystem/NamingSystemMsgcGCBA"
      },
      "name" : "NamingSystem URI MSGC GCBA (ejemplo)",
      "description" : "Sistema de identificadores de ejemplo para Parameters en este IG.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/sihce-privacy-level-vs"
      },
      "name" : "Niveles de privacidad SIHCE",
      "description" : "Niveles admitidos en Consent.provision.securityLabel (etapa 3).",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/sihce-privacy-level"
      },
      "name" : "Niveles de privacidad SIHCE",
      "description" : "Nivel de acceso documental otorgado a un hospital en el consentimiento del paciente (etapa 3).",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/ObservationLaboratorioSIHCE"
      },
      "name" : "Observación de laboratorio SIHCE",
      "description" : "Resultado analítico codificado (LOINC) asociado a un informe de laboratorio nivel 2.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/PatientXBA"
      },
      "name" : "Paciente SIHCE (PatientXBA)",
      "description" : "Perfil de Patient para interoperabilidad SIHCE vía X-BA (empadronamiento y federación)",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/parametros-patch-identifier-sihce"
      },
      "name" : "Parametros Patch Identifier SIHCE",
      "description" : "Estructura de Parameters para la operacion $patch-identifier de SIHCE.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/parametros-update-sdm-sihce"
      },
      "name" : "Parametros Update SDM SIHCE",
      "description" : "Estructura de Parameters para la operacion $update-sdm de SIHCE.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/parametros-get-binary-id-sihce"
      },
      "name" : "Parámetros DocumentReference/$get_binary_id SIHCE",
      "description" : "Entrada de la operación que canjea una URL temporaria del índice por la URL real en el dominio emisor y un token de acceso al documento.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Patient"
      }],
      "reference" : {
        "reference" : "Patient/PersonaSIHCEMin"
      },
      "name" : "PersonaSIHCEMin",
      "description" : "Ejemplo de Recurso Paciente con Set de Datos Minimos",
      "isExample" : true,
      "profile" : ["http://sihce.gob.ar/StructureDefinition/PatientXBA"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "Patient"
      }],
      "reference" : {
        "reference" : "Patient/PersonaSIHCEPatch"
      },
      "name" : "PersonaSIHCEPatch",
      "description" : "Ejemplo de Recurso Paciente para Patch de Datos Minimos",
      "isExample" : true,
      "profile" : ["http://sihce.gob.ar/StructureDefinition/PatientXBA"]
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/DocumentReferenceSIHCE"
      },
      "name" : "Referencia a documento clínico SIHCE",
      "description" : "Índice federado de documentos clínicos. El dominio emisor registra metadatos en SIHCE con la URL real en content.attachment.url; en consultas GET, SIHCE devuelve URLs temporarias enmascaradas. El contenido se obtiene vía DocumentReference/$get_binary_id y GET al dominio emisor. SIHCE valida Consent antes de listar o canjear.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "NamingSystem"
      }],
      "reference" : {
        "reference" : "NamingSystem/renaper-dni"
      },
      "name" : "renaper-dni",
      "description" : "This NamingSystem defines the official identification document issued by RENAPER in Argentina, the Documento Nacional de Identidad (DNI).",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:resource"
      }],
      "reference" : {
        "reference" : "StructureDefinition/parametros-get-binary-id-response-sihce"
      },
      "name" : "Respuesta DocumentReference/$get_binary_id SIHCE",
      "description" : "URL real del contenido en el dominio emisor, token de acceso y vigencia opcional.",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/sihce-logical-operation-element-paths"
      },
      "name" : "Rutas de elementos en modelos lógicos de operación SIHCE",
      "description" : "Códigos usados como origen en ConceptMap (rutas tipo LogicalRoot.segmento...).",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "CodeSystem"
      }],
      "reference" : {
        "reference" : "CodeSystem/sihce-fhir-core-element-paths"
      },
      "name" : "Rutas de elementos FHIR usadas como destino en ConceptMap SIHCE",
      "description" : "Códigos de correlación con Patient, Organization y OperationOutcome (no canónicos de StructureDefinition).",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/sihce-epicrisis-section-vs"
      },
      "name" : "Secciones LOINC de epicrisis SIHCE",
      "description" : "Secciones de CompositionEpicrisisSIHCE (obligatorias y opcionales).",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/sihce-clinical-document-type-vs"
      },
      "name" : "Tipos de documento clínico SIHCE",
      "description" : "Tipos documentales admitidos en DocumentReferenceSIHCE (LOINC).",
      "isExample" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ValueSet"
      }],
      "reference" : {
        "reference" : "ValueSet/sihce-document-content-type-vs"
      },
      "name" : "Tipos MIME de contenido documental SIHCE",
      "description" : "Formatos admitidos en DocumentReference.content.attachment.contentType.",
      "isExample" : false
    }],
    "page" : {
      "sourceUrl" : "toc.html",
      "name" : "toc.html",
      "title" : "Table of Contents",
      "generation" : "html",
      "page" : [{
        "sourceUrl" : "index.html",
        "name" : "index.html",
        "title" : "Inicio",
        "generation" : "markdown"
      },
      {
        "sourceUrl" : "Aspectos-Generales.html",
        "name" : "Aspectos-Generales.html",
        "title" : "Generalidades",
        "generation" : "markdown"
      },
      {
        "sourceUrl" : "Operaciones.html",
        "name" : "Operaciones.html",
        "title" : "Operaciones",
        "generation" : "markdown"
      },
      {
        "sourceUrl" : "CasosDeUso.html",
        "name" : "CasosDeUso.html",
        "title" : "Casos de Uso",
        "generation" : "markdown"
      },
      {
        "sourceUrl" : "ModeloLogico.html",
        "name" : "ModeloLogico.html",
        "title" : "Modelo Lógico",
        "generation" : "markdown"
      },
      {
        "sourceUrl" : "Seguridad.html",
        "name" : "Seguridad.html",
        "title" : "Seguridad",
        "generation" : "markdown"
      },
      {
        "sourceUrl" : "HistorialDeCambios.html",
        "name" : "HistorialDeCambios.html",
        "title" : "Historial de Cambios",
        "generation" : "markdown"
      }]
    },
    "parameter" : [{
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "copyrightyear"
      },
      "value" : "2026"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "releaselabel"
      },
      "value" : "ci-build"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "tabbed-snapshots"
      },
      "value" : "false"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "autoload-resources"
      },
      "value" : "true"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-resource"
      },
      "value" : "input/capabilities"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-resource"
      },
      "value" : "input/examples"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-resource"
      },
      "value" : "input/extensions"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-resource"
      },
      "value" : "input/models"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-resource"
      },
      "value" : "input/operations"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-resource"
      },
      "value" : "input/profiles"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-resource"
      },
      "value" : "input/resources"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-resource"
      },
      "value" : "input/vocabulary"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-resource"
      },
      "value" : "input/maps"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-resource"
      },
      "value" : "input/testing"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-resource"
      },
      "value" : "input/history"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-resource"
      },
      "value" : "fsh-generated/resources"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-pages"
      },
      "value" : "template/config"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-pages"
      },
      "value" : "input/images"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "path-liquid"
      },
      "value" : "template/liquid"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "path-liquid"
      },
      "value" : "input/liquid"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "path-qa"
      },
      "value" : "temp/qa"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "path-temp"
      },
      "value" : "temp/pages"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "path-output"
      },
      "value" : "output"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/guide-parameter-code",
        "code" : "path-tx-cache"
      },
      "value" : "input-cache/txcache"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "path-suppressed-warnings"
      },
      "value" : "input/ignoreWarnings.txt"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "path-history"
      },
      "value" : "http://sihce.gob.ar/history.html"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "template-html"
      },
      "value" : "template-page.html"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "template-md"
      },
      "value" : "template-page-md.html"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "apply-contact"
      },
      "value" : "true"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "apply-context"
      },
      "value" : "true"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "apply-copyright"
      },
      "value" : "true"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "apply-jurisdiction"
      },
      "value" : "true"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "apply-license"
      },
      "value" : "true"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "apply-publisher"
      },
      "value" : "true"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "apply-version"
      },
      "value" : "true"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "apply-wg"
      },
      "value" : "true"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "active-tables"
      },
      "value" : "true"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "fmm-definition"
      },
      "value" : "http://hl7.org/fhir/versions.html#maturity"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "propagate-status"
      },
      "value" : "true"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "excludelogbinaryformat"
      },
      "value" : "true"
    },
    {
      "code" : {
        "system" : "http://hl7.org/fhir/tools/CodeSystem/ig-parameters",
        "code" : "i18n-default-lang"
      },
      "value" : "en"
    }]
  }
}

```
